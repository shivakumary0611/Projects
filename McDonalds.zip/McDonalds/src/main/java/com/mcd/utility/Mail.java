package com.mcd.utility;

import java.util.Properties;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class Mail {
    
    public boolean sendMail(String toMail, String name) {
        // Step 1: Define sender's Gmail address
        String from = "shivukumar2203@gmail.com";
        String password = "cuwsyenjqdyzocrg";
        
        // Step 2: Set SMTP server properties        
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        
        // Step 3: Create a session with authentication
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });
        
        try {
            // Step 4: Create and send the email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipient(Message.RecipientType.TO, new InternetAddress(toMail));
            message.setSubject("SignUp Successful");
            message.setText("Hello! MR/Ms " + name + " This is a test email sent from Java using Gmail SMTP. Your McDonald's signup was successful!...");
            
            // Step 5: Send the email
            Transport.send(message);
            
            System.out.println("✅ Email sent successfully!");
            return true;
            
        } catch (MessagingException e) {
            System.err.println("❌ Failed to send email: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}