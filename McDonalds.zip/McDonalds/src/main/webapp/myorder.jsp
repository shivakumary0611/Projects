<%@page import="com.mcd.models.Dao.UserDaoImpli"%>
<%@page import="com.mcd.models.Dao.UserDao"%>
<%@page import="com.mcd.models.Dto.Orders"%>
<%@page import="java.text.SimpleDateFormat"%>
<%@page import="java.text.ParseException"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.mcd.models.Dto.User" %>
<%@ page import="java.util.ArrayList" %>

<%
// Check if user is logged in
User user = (User) session.getAttribute("pass");
boolean isLoggedIn = user != null;
String username = isLoggedIn ? user.getName() : "Guest";

// Date formatters
SimpleDateFormat dbDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
SimpleDateFormat displayFormat = new SimpleDateFormat("MMM dd, yyyy hh:mm a");

// Fetch orders from database
UserDao udao = new UserDaoImpli();
ArrayList<Orders> orders = isLoggedIn ? udao.getOrderbyId(user.getUserId()) : new ArrayList<>();
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Delight | My Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin-top: 0;
            padding-top: 60px;
            background-color: #f8f9fa;
        }

        .navbar {
            background-color: #fff !important;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .order-table {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        .order-table th {
            background-color: #da291c;
            color: white;
            font-weight: 500;
        }

        .order-table tr:hover {
            background-color: rgba(218, 41, 28, 0.05);
        }

        .status-pending {
            color: #ffc107;
            font-weight: 500;
        }

        .status-delivered {
            color: #28a745;
            font-weight: 500;
        }

        .status-cancelled {
            color: #dc3545;
            font-weight: 500;
        }

        .status-processing {
            color: #17a2b8;
            font-weight: 500;
        }

        .order-id-link {
            color: #da291c;
            text-decoration: none;
            font-weight: 500;
        }

        .order-id-link:hover {
            text-decoration: underline;
        }

        .no-orders {
            text-align: center;
            padding: 50px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }

        .no-orders-icon {
            font-size: 5rem;
            color: #6c757d;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <header class="navbar navbar-expand-lg shadow fixed-top">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand fw-bold" href="home.jsp">
                <img src="Assets/Logo/logo-transparent-png.png" width="200" alt="Logo">
            </a>

            <!-- NAVBAR TOGGLER -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- NAVBAR ITEMS -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto d-flex align-items-center">
                    <li class="nav-item mx-1"><a class="nav-link" href="userhome.jsp">Home</a></li>
                    <li class="nav-item mx-1"><a class="nav-link active" href="menu.jsp">Menu</a></li>
                    <li class="nav-item mx-1"><a class="nav-link" href="about.jsp">About</a></li>
                    <li class="nav-item mx-1"><a class="nav-link" href="contact.jsp">Contact</a></li>
                    <% if(isLoggedIn) { %>
                        <div class="dropdown">
                            <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile" width="32" height="32" class="rounded-circle me-2">
                                <span class="d-none d-sm-inline"><%= username %></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
                                <li><a class="dropdown-item" href="profile.jsp"><i class="bi bi-person-fill me-2"></i>Profile</a></li>
                                <li><a class="dropdown-item" href="myorder.jsp"><i class="bi bi-list-check me-2"></i>My Orders</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li> <form action="Logout" method="post">
                                    <button type="submit" class="dropdown-item">Logout</button>
                                </form></li>
                            </ul>
                        </div>
                    <% } %>
                    
                    <li class="nav-item mx-2">
                        <a href="cart.jsp" class="btn btn-success position-relative">
                            <i class="bi bi-cart-fill"></i> Cart</a>
                    </li>
                    
                    <li class="nav-item mx-2">
                        <% if(isLoggedIn) { %>
                        <form action="Logout" method="post" class="d-inline">
                            <div class="d-flex align-items-center gap-2">
                                <button type="submit" class="btn btn-danger ms-2"><i class="bi bi-box-arrow-right"></i> Logout</button>
                            </div>
                        </form>
                        <% } else { %>
                            <div class="auth-buttons">
                                <a href="login.jsp" class="btn btn-primary">Login</a>
                                <a href="signup.jsp" class="btn btn-outline-primary">Sign Up</a>
                            </div>
                        <% } %>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container my-5">
        <div class="row mb-4">
            <div class="col">
                <h2 class="fw-bold">My Orders</h2>
                <p class="text-muted">View your order history and track current orders</p>
            </div>
        </div>
        
        <% if(isLoggedIn) { %>
            <% if(orders != null && !orders.isEmpty()) { %>
                <div class="table-responsive order-table">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Price</th>
                                <th>status</th>
                                <th>payment method</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for(Orders order : orders) { 
                                String formattedDate = "Date not available";
                                if(order.getOrder_date() != null && !order.getOrder_date().isEmpty()) {
                                    try {
                                        java.util.Date orderDate = dbDateFormat.parse(order.getOrder_date());
                                        formattedDate = displayFormat.format(orderDate);
                                    } catch (ParseException e) {
                                        formattedDate = order.getOrder_date();
                                    }
                                }
                                
                                // Determine status class
                                String statusClass = "";
                                if(order.getOrder_status() != null) {
                                    switch(order.getOrder_status().toLowerCase()) {
                                        case "pending": statusClass = "status-pending"; break;
                                        case "delivered": statusClass = "status-delivered"; break;
                                        case "cancelled": statusClass = "status-cancelled"; break;
                                        case "processing": statusClass = "status-processing"; break;
                                        default: statusClass = "";
                                    }
                                }
                            %>
                            <tr>
                                <td>
                                    <a href="orderDetails.jsp?order_id=<%= order.getOrder_id()%>&order_status=<%=order.getOrder_status()%>" class="order-id-link">
                                        #<%= order.getOrder_id() %>
                                    </a>
                                </td>
                                <td><%= formattedDate %></td>
                               <!-- <td><= order.getItem_count() != null ? order.getItem_count() : "N/A" %> items</td>-->
                                <td>₹<%= String.format("%.2f", order.getTotal_price()) %></td>
                                <td class="<%= statusClass %>">
                                    <%= order.getOrder_status() != null ? order.getOrder_status() : "Pending" %>
                                </td>
                                <td><%= order.getPayment_method() != null ? order.getPayment_method() : "N/A" %></td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            <% } else { %>
                <div class="no-orders">
                    <div class="no-orders-icon">
                        <i class="bi bi-cart-x"></i>
                    </div>
                    <h4 class="mb-3">No Orders Found</h4>
                    <p class="text-muted mb-4">You haven't placed any orders yet.</p>
                    <a href="menu.jsp" class="btn btn-primary">Browse Menu</a>
                </div>
            <% } %>
        <% } else { %>
            <div class="alert alert-warning">
                <h4>Please log in to view your orders</h4>
                <p>You need to be logged in to see your order history.</p>
                <a href="login.jsp" class="btn btn-primary">Login</a>
                <a href="signup.jsp" class="btn btn-outline-primary">Sign Up</a>
            </div>
        <% } %>
    </main>

    <!-- Footer -->
    <footer class="footer py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-start">
                    <h5>About Us</h5>
                    <p>Food Delight is your go-to platform for delicious meals, offering a wide variety of dishes crafted with love.</p>
                </div>
                <div class="col-md-4 text-center">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="userhome.jsp" class="footer-link">Home</a></li>
                        <li><a href="menu.jsp" class="footer-link">Menu</a></li>
                        <% if(isLoggedIn) { %>
                            <li><a href="myorders.jsp" class="footer-link">Orders</a></li>
                        <% } %>
                        <li><a href="about.jsp" class="footer-link">About</a></li>
                        <li><a href="contact.jsp" class="footer-link">Contact</a></li>
                    </ul>
                </div>
                <div class="col-md-4 text-end">
                    <h5>Follow Us</h5>
                    <a href="#" class="social-icon"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-youtube"></i></a>
                </div>
            </div>
            <div class="text-center mt-3">
                <p>&copy; 2023 Food Delight | All Rights Reserved</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>