<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@page import="com.mcd.models.Dto.User"%>  

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Delight | Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="styles.css">

    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin-top: 0;
            padding-top: 60px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Navbar */
        .navbar {
            transition: all 0.3s ease-in-out;
            padding: 0.5rem 0;
        }

        .navbar-brand img {
            max-width: 150px;
            height: auto;
        }

        /* Profile Section */
        .update-user-section {
            max-width: 500px;
            margin: 100px auto 50px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
        }

        .update-user-section h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Footer */
        .footer {
            background-color: #fff;
            color: #333;
            padding: 30px 0;
            font-size: 16px;
            border-top: 2px solid #ddd;
        }

        .footer h5 {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        /* Dark Mode Styles */
        body.dark-mode {
            background-color: #121212;
            color: #e0e0e0;
        }

        .dark-mode .navbar {
            background-color: #222 !important;
        }

        .dark-mode .update-user-section {
            background-color: #222 !important;
            color: #fff !important;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
        }

        .dark-mode .footer {
            background-color: #222 !important;
            color: #ddd !important;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .navbar-brand img {
                max-width: 120px;
            }
            
            .update-user-section {
                margin: 80px auto 30px;
                padding: 15px;
            }
            
            .footer .col-md-4 {
                text-align: center !important;
                margin-bottom: 20px;
            }
            
            .footer .text-end {
                text-align: center !important;
            }
        }

        @media (max-width: 576px) {
            body {
                padding-top: 56px;
            }
            
            .update-user-section {
                margin: 70px 15px 20px;
                padding: 15px;
            }
            
            .navbar-collapse {
                padding: 10px 0;
            }
            
            .nav-item {
                margin: 5px 0;
            }
            
            .search-input {
                width: 100% !important;
                margin-bottom: 10px;
            }
        }

        /* Message Styles */
        .alert-message {
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 90%;
            max-width: 500px;
            text-align: center;
        }
    </style>
</head>

<body>

    <!-- Header Section -->
    <header class="navbar navbar-expand-lg navbar-light bg-white shadow fixed-top">
        <div class="container">
            <!-- LOGO -->
            <a class="navbar-brand fw-bold" href="admin.html">
                <img src="resources/images/logo-transparent-png.png" alt="Logo" class="img-fluid">
            </a>

            <!-- NAVBAR TOGGLER (For Mobile View) -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- NAVBAR ITEMS -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto d-flex align-items-center">
                    <!-- NAVIGATION LINKS -->
                    <li class="nav-item"><a class="nav-link active" href="admin.html">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="foods.html">Foods</a></li>
                    <li class="nav-item"><a class="nav-link" href="orders.html">Orders</a></li>
                    <li class="nav-item"><a class="nav-link" href="customers.html">Customers</a></li>

                    <!-- THEME TOGGLE -->
                    <li class="nav-item mx-2">
                        <button id="themeToggle" class="btn theme-toggle-btn">
                            <i id="themeIcon" class="bi bi-moon-fill"></i>
                        </button>
                    </li>

                    <!-- LOGOUT BUTTON -->
                    <li class="nav-item">
                        <button type="button" class="btn btn-danger">
                            <a href="login.html" class="text-white text-decoration-none">Logout</a>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </header>

    <!-- Messages -->
    <%User user = (User) session.getAttribute("user"); %>
    <%String UpdateSuccess = (String) session.getAttribute("UpdateSuccess"); if(UpdateSuccess != null){ %>
    <div class="alert alert-success alert-message alert-dismissible fade show" role="alert">
        <%=UpdateSuccess %>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <%session.removeAttribute("UpdateSuccess"); %>    
    <%} %>

    <%String UpdateFailed = (String) session.getAttribute("UpdateFailed"); if(UpdateFailed != null){ %>
    <div class="alert alert-danger alert-message alert-dismissible fade show" role="alert">
        <%=UpdateFailed %>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <%session.removeAttribute("UpdateFailed"); %>
    <%} %>

    <!-- Profile Update Section -->
    <section class="update-user-section">
        <h2>Update Profile</h2>
        <form action="updateprofile" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" value="<%=user.getName() %>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" value="<%=user.getEmail() %>" required>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter your phone number" value="<%=user.getPhone() %>" required>
            </div>

            <div class="mb-3">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" id="dob" name="dob" value="<%=user.getDob() %>" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="password" name="password" value="<%=user.getPassword() %>" placeholder="Enter new password" required>
            </div>

            <button type="submit" class="btn btn-warning w-100">Update Profile</button>
        </form>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <!-- About Section -->
                <div class="col-md-4 text-start">
                    <h5>About Us</h5>
                    <p>Food Delight is your go-to platform for delicious meals, offering a wide variety of dishes crafted with love.</p>
                </div>

                <!-- Navigation Links -->
                <div class="col-md-4 text-center">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="admin.html" class="footer-link">Home</a></li>
                        <li><a href="foods.html" class="footer-link">Foods</a></li>
                        <li><a href="orders.html" class="footer-link">Orders</a></li>
                        <li><a href="customers.html" class="footer-link">Customers</a></li>
                    </ul>
                </div>

                <!-- Social Media -->
                <div class="col-md-4 text-end">
                    <h5>Follow Us</h5>
                    <a href="#" class="social-icon"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="bi bi-youtube"></i></a>
                </div>
            </div>

            <!-- Copyright Section -->
            <div class="text-center mt-3">
                <p class="mb-0">&copy; 2025 Food Delight | All Rights Reserved</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const themeToggle = document.getElementById("themeToggle");
            const themeIcon = document.getElementById("themeIcon");
            const body = document.body;

            // Load theme from localStorage
            if (localStorage.getItem("theme") === "dark") {
                body.classList.add("dark-mode");
                themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
            }

            // Toggle theme on icon click
            themeToggle.addEventListener("click", function () {
                body.classList.toggle("dark-mode");

                if (body.classList.contains("dark-mode")) {
                    themeIcon.classList.replace("bi-moon-fill", "bi-sun-fill");
                    localStorage.setItem("theme", "dark");
                } else {
                    themeIcon.classList.replace("bi-sun-fill", "bi-moon-fill");
                    localStorage.setItem("theme", "light");
                }
            });
            
            // Auto-dismiss alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    const bsAlert = new bootstrap.Alert(alert);
                    bsAlert.close();
                }, 5000);
            });
        });
    </script>
</body>
</html>